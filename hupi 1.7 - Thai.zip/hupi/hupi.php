<?php
/**
 *   2009-2018 ohmyweb!
 *
 *   @author    ohmyweb <contact@ohmyweb.fr>
 *   @copyright 2009-2018 ohmyweb!
 *   @license   Proprietary - no redistribution without authorization
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Product\ProductListingPresenter;
use PrestaShop\PrestaShop\Adapter\Image\ImageRetriever;
use PrestaShop\PrestaShop\Adapter\Product\PriceFormatter;
use PrestaShop\PrestaShop\Adapter\Product\ProductColorsRetriever;

class Hupi extends Module
{
    protected $config_form = false;

    protected $js_state = 0;
    protected $eligible = 0;
    protected $filterable = 1;
    protected static $products = array();

    protected static $impressionProducts = array();
    protected static $recommendedProducts = array();

    public function __construct()
    {
        $this->bootstrap = true;
        $this->name = 'hupi';
        $this->tab = 'front_office_features';
        $this->version = '1.7.0';
        $this->author = 'Hupi';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = $this->l('Hupi');
        $this->description = $this->l('This allow to send analytics data within hupi\'s servers and display recommendations');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall my module?');
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
    }

    public function install()
    {
        if(parent::install()
            && $this->installDB()
            && $this->installConfigValue()
            && $this->registerHook('displayHeader')
            && $this->registerHook('backOfficeHeader')
            && $this->registerHook('actionCartSave')
            && $this->registerHook('displayAdminOrderContentOrder')
            && $this->registerHook('displayHome')
            && $this->registerHook('displayBeforeBodyClosingTag')
            && $this->registerHook('displayOrderConfirmation')
            && $this->registerHook('displayFooterProduct')
            && $this->registerHook('displayLeftColumn')
            && $this->registerHook('displayShoppingCartFooter')
            && $this->registerHook('displayHupiRecommendations')) {
            return true;
        }

        return $this->uninstall();
    }

    public function uninstall()
    {
        return parent::uninstall()
            && $this->uninstallDB()
            && $this->uninstallConfigValue()
            ;
    }

    public function installDB()
    {
        $statements = array();

        $statements[] = "
            CREATE TABLE IF NOT EXISTS `"._DB_PREFIX_."hupi` (
                `id_hupi` int(11) NOT NULL AUTO_INCREMENT,
                `id_order` int(11) NOT NULL,
                `id_customer` int(10) NOT NULL,
                `id_shop` int(11) NOT NULL,
                `sent` tinyint(1) DEFAULT NULL,
                `date_add` datetime DEFAULT NULL,
                PRIMARY KEY (`id_hupi`),
                KEY `id_order` (`id_order`),
                KEY `sent` (`sent`)
            ) ENGINE="._MYSQL_ENGINE_." DEFAULT CHARSET=utf8;
        ";

        foreach ($statements as $statement) {
            if (!Db::getInstance()->Execute($statement)) {
                $this->_errors[] = $this->l('Unable to execute the query : '.$statement);
                return false;
            }
        }

        return true;
    }

    public function installConfigValue()
    {
        if(Configuration::updateValue('HUPI_ACCOUNT_ID', null)
            && Configuration::updateValue('HUPI_SITE_ID', null)
            && Configuration::updateValue('HUPI_USERID_ENABLED', null)) {
            return true;
        }

        return false;
    }

    public function uninstallDB()
    {
        $statements = array();

        $statements[] = "DROP TABLE IF EXISTS `"._DB_PREFIX_."hupi`";

        foreach ($statements as $statement) {
            if (!Db::getInstance()->Execute($statement)) {
                $this->_errors[] = $this->l('Unable to execute the query : '.$statement);
                return false;
            }
        }

        return true;
    }

    public function uninstallConfigValue()
    {
        if(Configuration::deleteByName('HUPI_ACCOUNT_ID')
            && Configuration::deleteByName('HUPI_SITE_ID')
            && Configuration::deleteByName('HUPI_USERID_ENABLED')) {
            return true;
        }

        return false;
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {

        $output = '';
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitHupiModule')) == true) {
            $this->postProcess();
        }

        if (version_compare(_PS_VERSION_, '1.5', '>='))
            $output .= $this->renderForm();
        else
        {
            $this->context->smarty->assign(array(
                'account_id'        => Configuration::get('HUPI_ACCOUNT_ID'),
                'site_id'           => Configuration::get('HUPI_ACCOUNT_ID'),
                'userid_enabled'    => Configuration::get('HUPI_USERID_ENABLED'),
            ));
            $output .= $this->display(__FILE__, 'views/templates/admin/form-ps14.tpl');
        }

        $token = Configuration::get('HUPIRECO_TOKEN');
        $active_recommendation = Configuration::get('HUPIRECO_ACTIVE');

        $product_page = array(
            'active'        => Configuration::get('HUPIRECO_PROD_ACTIVE'),
            'end_point'     => Configuration::get('HUPIRECO_PROD_ENDPOINT'),
            'nb_products'   => Configuration::get('HUPIRECO_PROD_NB'),
        );
        $shopping_cart = array(
            'active'        => Configuration::get('HUPIRECO_CART_ACTIVE'),
            'end_point'     => Configuration::get('HUPIRECO_CART_ENDPOINT'),
            'nb_products'   => Configuration::get('HUPIRECO_CART_NB'),
        );
        $category = array(
            'active'        => Configuration::get('HUPIRECO_CATEGORY_ACTIVE'),
            'end_point'     => Configuration::get('HUPIRECO_CATEGORY_ENDPOINT'),
            'nb_products'   => Configuration::get('HUPIRECO_CATEGORY_NB'),
        );
        $homepage = array(
            'active'        => Configuration::get('HUPIRECO_HP_ACTIVE'),
            'end_point'     => Configuration::get('HUPIRECO_HP_ENDPOINT'),
            'nb_products'   => Configuration::get('HUPIRECO_HP_NB'),
        );
        if (Tools::isSubmit('updateConfig')) {
            $token = Tools::getValue('hupireco_token');
            $active_recommendation = Tools::getValue('active_recommendation');

            Configuration::updateValue('HUPIRECO_TOKEN', $token);
            Configuration::updateValue('HUPIRECO_ACTIVE', $active_recommendation);

            if($product_page = Tools::getValue('product_page')) {
                Configuration::updateValue('HUPIRECO_PROD_ACTIVE', $product_page['active']);
                Configuration::updateValue('HUPIRECO_PROD_ENDPOINT', $product_page['end_point']);
                Configuration::updateValue('HUPIRECO_PROD_NB', $product_page['nb_products']);
            }
            if($shopping_cart = Tools::getValue('shopping_cart')) {
                Configuration::updateValue('HUPIRECO_CART_ACTIVE', $shopping_cart['active']);
                Configuration::updateValue('HUPIRECO_CART_ENDPOINT', $shopping_cart['end_point']);
                Configuration::updateValue('HUPIRECO_CART_NB', $shopping_cart['nb_products']);
            }
            if($category = Tools::getValue('category')) {
                Configuration::updateValue('HUPIRECO_CATEGORY_ACTIVE', $category['active']);
                Configuration::updateValue('HUPIRECO_CATEGORY_ENDPOINT', $category['end_point']);
                Configuration::updateValue('HUPIRECO_CATEGORY_NB', $category['nb_products']);
            }
            if($homepage = Tools::getValue('homepage')) {
                Configuration::updateValue('HUPIRECO_HP_ACTIVE', $homepage['active']);
                Configuration::updateValue('HUPIRECO_HP_ENDPOINT', $homepage['end_point']);
                Configuration::updateValue('HUPIRECO_HP_NB', $homepage['nb_products']);
            }
        }

        $this->context->controller->addCSS($this->_path.'views/css/back.css');
        $this->context->smarty->assign(array(
            'module_dir' => $this->_path,
            'active_recommendation' => $active_recommendation,
            'hupireco_token' => $token,
            'product_page' => $product_page,
            'shopping_cart' => $shopping_cart,
            'category' => $category,
            'homepage' => $homepage,
        ));
        return $output.$this->context->smarty->fetch($this->local_path.'views/templates/admin/configure.tpl');
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitHupiModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            .'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        // Load current value
        $helper->fields_value['HUPI_ACCOUNT_ID'] = Configuration::get('HUPI_ACCOUNT_ID');
        $helper->fields_value['HUPI_SITE_ID'] = Configuration::get('HUPI_SITE_ID');
        $helper->fields_value['HUPI_USERID_ENABLED'] = Configuration::get('HUPI_USERID_ENABLED');

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->trans('Settings', array(), 'Admin.Global'),
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Hupi Analytics Account ID'),
                        'name' => 'HUPI_ACCOUNT_ID',
                        'size' => 20,
                        'required' => true,
                        'hint' => $this->l('This information is provided by Hupi')
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Hupi Analytics Site ID'),
                        'name' => 'HUPI_SITE_ID',
                        'size' => 20,
                        'required' => true,
                        'hint' => $this->l('This information is provided by Hupi')
                    ),
                    array(
                        'type' => 'radio',
                        'label' => $this->l('Enable User ID tracking'),
                        'name' => 'HUPI_USERID_ENABLED',
                        'values'    => array(
                            array(
                                'id' => 'hupi_userid_enabled',
                                'value' => 1,
                                'label' => $this->trans('Enabled', array(), 'Admin.Global')
                            ),
                            array(
                                'id' => 'hupi_userid_disabled',
                                'value' => 0,
                                'label' => $this->trans('Disabled', array(), 'Admin.Global')
                            ),
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->trans('Disabled', array(), 'Admin.Actions'),
                )
            )
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'HUPI_ACCOUNT_ID'       => Configuration::get('HUPI_ACCOUNT_ID'),
            'HUPI_SITE_ID'          => Configuration::get('HUPI_SITE_ID'),
            'HUPI_USERID_ENABLED'   => Configuration::get('HUPI_USERID_ENABLED'),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    protected function getProducts($endpoint, $nbProducts = 4, $extraParams = array()) {
        $id_lang = $this->context->language->id;

        if($this->context->cookie->__get('pk_id') && Configuration::get('HUPIRECO_TOKEN')) {
            $arrayPkId = explode('.', $this->context->cookie->__get('pk_id'));
            $visitor_id = array_shift($arrayPkId);
            $filters = array("visitor_id" => $visitor_id);
            if(isset($extraParams['id_product'])) {
                $filters['id_demande'] = $extraParams['id_product'];
            }
            if(isset($extraParams['id_category'])) {
                $filters['id_category'] = $extraParams['id_category'];
            }

            //var_dump($filters);
            if($products = $this->context->cart->getProducts(true)) {
                $productList = array();
                foreach ($products as $product) {
                    $productList[] = (int)$product['id_product'];
                }
                if($productList) {
                    $filters['basket'] = json_encode($productList);
                }
            }

            $data = array("client" => Configuration::get('HUPI_ACCOUNT_ID'), "render_type" => "cursor", "filters" => json_encode($filters));
            $data_string = json_encode($data);

            $ch = curl_init("https://api.dataretriever.thai.cloud-torus.com/private/".Configuration::get('HUPI_ACCOUNT_ID')."/".$endpoint);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT_MS, 400);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Accept-Version: v1',
                'X-API-Token: '.Configuration::get('HUPIRECO_TOKEN'),
                'Content-Length: ' . strlen($data_string)
            ));

            $result = curl_exec($ch);
//            var_dump($result);die;
            curl_close($ch);

            $jsonArray = json_decode($result, true);

            if(isset($jsonArray['error'])) {
                return;
            }

            if($jsonArray['data'] && count($jsonArray['data'])) {
                if(key(current($jsonArray['data'])) == 'idRs') {
                    $idProducts = current(array_values(array_map('current',$jsonArray['data'])));
                }
                else {
                    $idProducts = array_values(array_map('current',$jsonArray['data']));
                }

                $sql = 'SELECT p.*, product_shop.*, stock.`out_of_stock` out_of_stock, pl.`description`, pl.`description_short`,
                            pl.`link_rewrite`, pl.`meta_description`, pl.`meta_keywords`, pl.`meta_title`, pl.`name`,
                            p.`ean13`, p.`upc`, MAX(image_shop.`id_image`) id_image, il.`legend`
                        FROM `'._DB_PREFIX_.'product` p
                        LEFT JOIN `'._DB_PREFIX_.'product_lang` pl ON (
                            p.`id_product` = pl.`id_product`
                            AND pl.`id_lang` = '.(int)$id_lang.Shop::addSqlRestrictionOnLang('pl').'
                        )
                        '.Shop::addSqlAssociation('product', 'p').'
                        LEFT JOIN `'._DB_PREFIX_.'image` i ON (i.`id_product` = p.`id_product`)'.
                    Shop::addSqlAssociation('image', 'i', false, 'image_shop.cover=1').'
                        LEFT JOIN `'._DB_PREFIX_.'image_lang` il ON (i.`id_image` = il.`id_image` AND il.`id_lang` = '.(int)$id_lang.')
                        '.Product::sqlStock('p', 0).'
                        WHERE 1
                            AND p.`id_product` IN ('.implode(',', $idProducts).')
                            AND product_shop.`visibility` IN ("both", "catalog")
                            AND product_shop.`active` = 1
                        GROUP BY product_shop.id_product
                        ORDER BY FIELD(p.`id_product`, '.implode(',', $idProducts).')
                        LIMIT 0, '. (int)$nbProducts;

                $result = Db::getInstance(_PS_USE_SQL_SLAVE_)->executeS($sql);
                $products = Product::getProductsProperties($id_lang, $result);

                $assembler = new ProductAssembler($this->context);

                $presenterFactory = new ProductPresenterFactory($this->context);
                $presentationSettings = $presenterFactory->getPresentationSettings();
                $presenter = new ProductListingPresenter(
                    new ImageRetriever(
                        $this->context->link
                    ),
                    $this->context->link,
                    new PriceFormatter(),
                    new ProductColorsRetriever(),
                    $this->context->getTranslator()
                );

                $products_for_template = [];

                foreach ($products as $rawProduct) {
                    $products_for_template[] = $presenter->present(
                        $presentationSettings,
                        $assembler->assembleProduct($rawProduct),
                        $this->context->language
                    );
                }

                return $products_for_template;
            }
        }

        return array();
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookDisplayHeader($params)
    {
        if (Configuration::get('HUPI_ACCOUNT_ID'))
        {
            $this->context->controller->registerJavascript('modules-hupilytics', 'modules/hupi/views/js/hupilytics.js', array('position' => 'bottom', 'priority' => 150));
            $this->context->controller->registerJavascript('modules-hupi-action', 'modules/hupi/views/js/hupi-action-lib.js', array('position' => 'bottom', 'priority' => 150));
            $this->context->controller->registerStylesheet( 'modules-hupi', 'modules/hupi/views/css/front.css', [
                'media'    => 'all',
                'priority' => 150
            ] );

            return $this->_getHupiTag();
        }

    }

    /**
     * wrap products to provide a standard products information for google analytics script
     */
    public function wrapProducts($products, $extras = array(), $full = false)
    {
        $result_products = array();
        if (!is_array($products))
            return;

        $currency = new Currency($this->context->currency->id);
        $usetax = (Product::getTaxCalculationMethod((int)$this->context->customer->id) != PS_TAX_EXC);

        if (count($products) > 20) {
            $full = false;
        }
        else {
            $full = true;

            foreach ($products as $index => $product) {
                if ($product instanceof Product) {
                    $product = (array)$product;
                }

                if (!isset($product['price'])) {
                    $product['price'] = (float)Tools::displayPrice(Product::getPriceStatic((int)$product['id_product'], $usetax), $currency);
                }
                $result_products[] = $this->wrapProduct($product, $extras, $index, $full);
            }
        }

        return $result_products;
    }

    /**
     * wrap product to provide a standard product information for google analytics script
     */
    public function wrapProduct($product, $extras, $index = 0, $full = false)
    {
        $hupi_product = '';

        $variant = null;
        if (isset($product['attributes_small'])) {
            $variant = $product['attributes_small'];
        }
        elseif (isset($extras['attributes_small'])) {
            $variant = $extras['attributes_small'];
        }

        $product_qty = 1;
        if (isset($extras['qty'])) {
            $product_qty = $extras['qty'];
        }
        elseif (isset($product['cart_quantity'])) {
            $product_qty = $product['cart_quantity'];
        }

        $product_id = 0;
        if (!empty($product['id_product'])) {
            $product_id = $product['id_product'];
        }
        else if (!empty($product['id'])) {
            $product_id = $product['id'];
        }

//         if (!empty($product['id_product_attribute'])) {
//             $product_id .= '-'. $product['id_product_attribute'];
//         }

        $product_type = 'typical';
        if (isset($product['pack']) && $product['pack'] == 1) {
            $product_type = 'pack';
        }
        elseif (isset($product['virtual']) && $product['virtual'] == 1) {
            $product_type = 'virtual';
        }

        if ($full) {
            $price = (isset($product['price_amount'])?$product['price_amount']:$product['price']);
            $hupi_product = array(
                'id' => (string)$product_id,
                'name' => json_encode($product['name']),
                'category' => json_encode($product['category']),
                'brand' => isset($product['manufacturer_name']) ? json_encode($product['manufacturer_name']) : '',
                'variant' => json_encode($variant),
                'type' => $product_type,
                'position' => $index ? $index : '0',
                'quantity' => $product_qty,
                'list' => Tools::getValue('controller'),
                'url' => isset($product['link']) ? urlencode($product['link']) : '',
                'price' => number_format($price, '2')
            );
        }
        else {
            $hupi_product = array(
                'id' => $product_id,
                'name' => json_encode($product['name'])
            );
        }
        return $hupi_product;
    }

    /**
     * add product impression js and product click js
     */
    public function addProductRecommendationImpression($products)
    {
        if (!is_array($products))
            return;

        $js = '';
        $js .= "console.log('setCustomVariable : products_recommendation => ".implode(',', $products)."');";
        $js .= 'HupiEnhancedECommerce.setCustomVariable('.json_encode(array('id' => 40, 'cvar_name' => 'products_recommendation', 'cvar_value' => array_values($products), 'scope' => 'page')).');';
        //$js .= 'HupiEnhancedECommerce.addProductImpression('.json_encode($product).",'',true);";

        return $js;
    }

    /**
     * add product impression js and product click js
     */
    public function addProductImpression($products)
    {
        if (!is_array($products))
            return;

        $js = '';
        $productsIds = array();
        foreach ($products as $product) {
//             $productsIds[] = $product['id'];
            self::$impressionProducts[] = $product['id'];
        }
//         $js .= "console.log('setCustomVariable : products_impression => ".implode(',', $productsIds)."');";
//         $js .= 'HupiEnhancedECommerce.setCustomVariable('.json_encode(array('id' => 30, 'cvar_name' => 'products_impression', 'cvar_value' => $productsIds, 'scope' => 'page')).');';
        //$js .= 'HupiEnhancedECommerce.addProductImpression('.json_encode($product).",'',true);";

        return $js;
    }

    /**
     * add order transaction
     */
    public function addTransaction($products, $order)
    {
        if (!is_array($products))
            return;

        $js = '';
        foreach ($products as $product)
            $js .= 'HupiEnhancedECommerce.add('.json_encode($product).');';

        return $js.'HupiEnhancedECommerce.addTransaction('.json_encode($order).');';
    }

    public function addProductClick($products)
    {
        if (!is_array($products))
            return;

        $js = '';
        foreach ($products as $product)
            $js .= 'HupiEnhancedECommerce.addProductClick('.json_encode($product).');';

        return $js;
    }

    public function addProductClickByHttpReferal($products)
    {
        if (!is_array($products)) {
            return;
        }

        $js = '';
        foreach ($products as $product) {
            $js .= 'HupiEnhancedECommerce.addProductClickByHttpReferal('.json_encode($product).');';
        }

        return $js;
    }


    protected function filter($hupi_scripts)
    {
        if ($this->filterable = 1)
            return implode(';', array_unique(explode(';', $hupi_scripts)));

        return $hupi_scripts;
    }

    /**
     * Add product checkout info
     */
    public function addProductFromCheckout($products)
    {
        if (!is_array($products))
            return;

        $js = '';
        foreach ($products as $product)
            $js .= 'HupiEnhancedECommerce.add('.json_encode($product).');';

        return $js;
    }

    /**
     * hook home to display generate the product list associated to home featured, news products and best sellers Modules
     */
    public function isModuleEnabled($module_name)
    {
        if (($module = Module::getInstanceByName($module_name)) !== false &&
            Module::isInstalled($module_name) &&
            $module->active) {
            return $module->registerHook('displayHome');
        }
    }


    /**
     * Generate Google Analytics js
     */
    public function _runJs($js_code, $backoffice = 0)
    {
        if (Configuration::get('HUPI_ACCOUNT_ID'))
        {
            $runjs_code = '
                <script type="text/javascript">
                    HupiEnhancedECommerce.init('.(int)_PS_MODE_DEV_.');
                ';
            if(Configuration::get('HUPIRECO_ACTIVE') == '1') {
                $products = array_unique(self::$recommendedProducts);
                if(count($products)) {
                    $runjs_code .= $this->addProductRecommendationImpression($products);
                }
            }
            $runjs_code .= '</script>';

            if (!empty($js_code)) {
                $runjs_code .= '
                <script type="text/javascript">
                    '.$js_code.'
                </script>';
            }
//				pk_id = null;
//              _paq.push([ function() { pk_id = this.getVisitorId(); }]);

            if($arrPkId = preg_grep( "#_pk_id_#", array_keys($_COOKIE))) {
                $this->context->cookie->__set('pk_id' , $_COOKIE[array_pop($arrPkId)]);
            }

            if (($this->js_state) != 1 && ($backoffice == 0)) {
                $runjs_code .= '
			<script type="text/javascript">
                console.log(\'trackPageView\');
                _paq.push([\'trackPageView\']);
                    
                console.log(\'enableLinkTracking\');
                _paq.push([\'enableLinkTracking\']);
			</script>';
            }

            return $runjs_code;
        }
    }

    protected function _getHupiTag($back_office = false)
    {
        $user_id = null;
        if (Configuration::get('HUPI_USERID_ENABLED') &&
            $this->context->customer && $this->context->customer->isLogged()
        ){
            $user_id = (int)$this->context->customer->id;
        }

        return '
            <script type="text/javascript">
              var _paq = _paq || [];
              (function()
              {
                var u = "https://api.catchbox.thai.cloud-torus.com/v2/'.Tools::safeOutput(Configuration::get('HUPI_ACCOUNT_ID')).'/hupilytics";
                _paq.push([\'setTrackerUrl\', u]);  // Required
                _paq.push([\'setSiteId\', '.(int)Tools::safeOutput(Configuration::get('HUPI_SITE_ID')).']);  // Required: must be an integer
                '.
            ($user_id?'_paq.push([\'setUserId\', \''.$user_id.'\']);':'')
            .'
                var d=document, g=d.createElement(\'script\'), s=d.getElementsByTagName(\'script\')[0];
                g.type=\'text/javascript\';
                g.defer=true;
                g.async=true;
                g.src=u;
                s.parentNode.insertBefore(g,s);
              })();
            </script>';
    }


    /**
     * Hook admin office header to add google analytics js
     */
    public function hookActionProductCancel($params)
    {
        $qty_refunded = Tools::getValue('cancelQuantity');
        $hupi_scripts = '';
        foreach ($qty_refunded as $orderdetail_id => $qty)
        {
            // Display Hupi refund product
            $order_detail = new OrderDetail($orderdetail_id);
            $hupi_scripts .= 'HupiEnhancedECommerce.add('.json_encode(
                    array(
                        'id' => empty($order_detail->product_attribute_id)?$order_detail->product_id:$order_detail->product_id.'-'.$order_detail->product_attribute_id,
                        'quantity' => $qty)
                ).');';
        }
        $this->context->cookie->hupi_admin_refund = $hupi_scripts.'HupiEnhancedECommerce.refundByProduct('.json_encode(array('id' => $params['order']->id)).');';
    }

    public function hookActionCartSave()
    {
        if (!isset($this->context->cart))
            return;

        if (!Tools::getIsset('id_product'))
            return;

        $cart = array(
            'controller' => Tools::getValue('controller'),
            'addAction' => Tools::getValue('add') ? 'add' : '',
            'removeAction' => Tools::getValue('delete') ? 'delete' : '',
            'extraAction' => Tools::getValue('op'),
            'qty' => (int)Tools::getValue('qty', 1)
        );

        $cart_products = $this->context->cart->getProducts();
        if (isset($cart_products) && count($cart_products))
            foreach ($cart_products as $cart_product)
                if ($cart_product['id_product'] == Tools::getValue('id_product'))
                    $add_product = $cart_product;

        if ($cart['removeAction'] == 'delete')
        {
            $add_product_object = new Product((int)Tools::getValue('id_product'), true, (int)Configuration::get('PS_LANG_DEFAULT'));
            if (Validate::isLoadedObject($add_product_object))
            {
                $add_product['name'] = $add_product_object->name;
                $add_product['manufacturer_name'] = $add_product_object->manufacturer_name;
                $add_product['category'] = $add_product_object->category;
                $add_product['reference'] = $add_product_object->reference;
                $add_product['link_rewrite'] = $add_product_object->link_rewrite;
                $add_product['link'] = $add_product_object->link_rewrite;
                $add_product['price'] = $add_product_object->price;
                $add_product['ean13'] = $add_product_object->ean13;
                $add_product['id_product'] = Tools::getValue('id_product');
                $add_product['id_category_default'] = $add_product_object->id_category_default;
                $add_product['out_of_stock'] = $add_product_object->out_of_stock;
                $add_product = Product::getProductProperties((int)Configuration::get('PS_LANG_DEFAULT'), $add_product);

                $add_product['price'] = $add_product['price_tax_exc'];
            }
        }

        if (isset($add_product) && !in_array((int)Tools::getValue('id_product'), self::$products))
        {
            self::$products[] = (int)Tools::getValue('id_product');
            $hupi_products = $this->wrapProduct($add_product, $cart, 0, true);

            if (array_key_exists('id_product_attribute', $hupi_products) && $hupi_products['id_product_attribute'] != '' && $hupi_products['id_product_attribute'] != 0)
                $id_product = $hupi_products['id_product_attribute'];
            else
                $id_product = Tools::getValue('id_product');

            if (isset($this->context->cookie->hupi_cart))
                $hupicart = unserialize($this->context->cookie->hupi_cart);
            else
                $hupicart = array();

            if ($cart['removeAction'] == 'delete') {
                $hupi_products['quantity'] = $cart['qty'] * -1;
            } elseif ($cart['extraAction'] == 'down') {
                if (array_key_exists($id_product, $hupicart)) {
                    $hupi_products['quantity'] = $hupicart[$id_product]['quantity'] - $cart['qty'];
                } else {
                    $hupi_products['quantity'] = $cart['qty'] * -1;
                }
            }
            elseif (Tools::getValue('step') <= 0) // Sometimes cartsave is called in checkout
            {
                if (array_key_exists($id_product, $hupicart)) {
                    $hupi_products['quantity'] = $hupicart[$id_product]['quantity'] + $cart['qty'];
                }
            }

            $hupicart[$id_product] = $hupi_products;
            $this->context->cookie->hupi_cart = serialize($hupicart);
        }
    }

    public function hookDisplayAdminOrderContentOrder()
    {
        echo $this->_runJs($this->context->cookie->hupi_admin_refund, 1);
        unset($this->context->cookie->hupi_admin_refund);
    }

    public function hookDisplayBeforeBodyClosingTag()
    {

        $hupi_scripts = '';
        $this->js_state = 0;

        if (isset($this->context->cookie->hupi_cart))
        {
            $this->filterable = 0;

            $hupicarts = unserialize($this->context->cookie->hupi_cart);
            foreach ($hupicarts as $hupicart)
            {
                if ($hupicart['quantity'] > 0) {
                    $hupi_scripts .= 'HupiEnhancedECommerce.addToCart('.json_encode($hupicart).');';
                } elseif ($hupicart['quantity'] < 0) {
                    $hupicart['quantity'] = abs($hupicart['quantity']);
                    $hupi_scripts .= 'HupiEnhancedECommerce.removeFromCart('.json_encode($hupicart).');';
                }
                $hupi_scripts .= 'HupiEnhancedECommerce.trackCartUpdate('.$this->context->cart->getOrderTotal(true, Cart::ONLY_PRODUCTS).');';
            }
            unset($this->context->cookie->hupi_cart);
        }

        $controller_name = Tools::getValue('controller');
        $products_displayed = $this->context->smarty->getTemplateVars('listing');
        $products = $this->wrapProducts($products_displayed['products'], array(), true);

        if ($controller_name == 'product')
        {
            // Add product view
            $product = new Product(Tools::getValue('id_product'), false, Context::getContext()->language->id);
            $hupi_product = $this->wrapProduct((array)$product, null, 0, true);
            $hupi_scripts .= 'HupiEnhancedECommerce.addProductDetailView('.json_encode($hupi_product).');';

            if (isset($_SERVER['HTTP_REFERER']) && strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']) > 0)
                $hupi_scripts .= $this->addProductClickByHttpReferal(array($hupi_product));

            $this->js_state = 1;
        }

        if ($controller_name == 'order' || $controller_name == 'orderopc')
        {
            $this->eligible = 1;
            $step = Tools::getValue('step');
            if (empty($step))
                $step = 0;
            $hupi_scripts .= $this->addProductFromCheckout($products, $step);
            $hupi_scripts .= 'HupiEnhancedECommerce.addCheckout(\''.(int)$step.'\');';
        }


        $confirmation_hook_id = (int)Hook::getIdByName('orderConfirmation');
        if (isset(Hook::$executed_hooks[$confirmation_hook_id]))
            $this->eligible = 1;

        if (isset($products) && count($products) && $controller_name != 'index')
        {
            if ($this->eligible == 0) {
                $hupi_scripts .= $this->addProductImpression($products);
            }
            $hupi_scripts .= $this->addProductClick($products);
        }

        if(count(self::$impressionProducts)) {
            $hupi_scripts .= "console.log('setCustomVariable : products_impression => ".implode(',', array_unique(self::$impressionProducts))."');";
            $hupi_scripts .= 'HupiEnhancedECommerce.setCustomVariable('.json_encode(array('id' => 30, 'cvar_name' => 'products_impression', 'cvar_value' => array_values(array_unique(self::$impressionProducts)), 'scope' => 'page')).');';
        }

        if(Configuration::get('HUPIRECO_ACTIVE') == '1') {
            $hupi_scripts .= 'HupiEnhancedECommerce.addProductRecommendationClick();';
        }

        return $this->_runJs($hupi_scripts);
    }

    public function hookDisplayOrderConfirmation($params)
    {
        $order = $params['order'];
        if (Validate::isLoadedObject($order) && $order->getCurrentState() != (int)Configuration::get('PS_OS_ERROR'))
        {
            $hupi_order_sent = Db::getInstance()->getValue('SELECT id_order FROM `'._DB_PREFIX_.'hupi` WHERE id_order = '.(int)$order->id);
            if ($hupi_order_sent === false)
            {
                Db::getInstance()->Execute('INSERT INTO `'._DB_PREFIX_.'hupi` (id_order, id_shop, sent, date_add) VALUES ('.(int)$order->id.', '.(int)$this->context->shop->id.', 0, NOW())');
                if ($order->id_customer == $this->context->cookie->id_customer)
                {
                    $order_products = array();
                    $cart = new Cart($order->id_cart);
                    foreach ($cart->getProducts() as $order_product)
                        $order_products[] = $this->wrapProduct($order_product, array(), 0, true);

                    $transaction = array(
                        'id' => $order->id,
                        'affiliation' => (version_compare(_PS_VERSION_, '1.5', '>=') && Shop::isFeatureActive()) ? $this->context->shop->name : Configuration::get('PS_SHOP_NAME'),
                        'total_tax_incl' => $order->total_paid_tax_incl,
                        'total_tax_excl' => $order->total_paid_tax_excl,
                        'tax' => $order->total_paid_tax_incl - $order->total_paid_tax_excl,
                        'shipping' => $order->total_shipping_tax_incl,
                        'url' => $this->context->link->getModuleLink('hupi', 'ajax', array(), true),
                        'customer' => $order->id_customer);
                    $hupi_scripts = $this->addTransaction($order_products, $transaction);

                    $this->js_state = 1;
                    return $this->_runJs($hupi_scripts);
                }
            }
        }
    }

    public function hookProductFooter($params)
    {
        if(Configuration::get('HUPIRECO_ACTIVE') != 1 || Configuration::get('HUPIRECO_PROD_ACTIVE') != '1' || !Configuration::get('HUPIRECO_PROD_ENDPOINT')) {
            return;
        }
        $nbProd = (int)Configuration::get('HUPIRECO_PROD_NB');
        if($nbProd == 0) {
            $nbProd = null;
        }

        $id_product = Tools::getValue('id_product');
        if($products = $this->getProducts(Configuration::get('HUPIRECO_PROD_ENDPOINT'), $nbProd, array('id_product' => $id_product))) {
            $this->smarty->assign(array(
                'products' => $products,
                'endpoint' => Configuration::get('HUPIRECO_PROD_ENDPOINT')
            ));

            foreach ($products as $product) {
                self::$recommendedProducts[] = $product['id_product'];
            }
            return $this->fetch('module:hupi/views/templates/hook/recommendations.tpl');
        }
    }

    public function hookDisplayHome($params)
    {
        $hupi_scripts = '';

        // Home featured products
        if ($this->isModuleEnabled('ps_featuredproducts')) {
            $category = new Category($this->context->shop->getCategory(), $this->context->language->id);
            $home_featured_products = $this->wrapProducts(
                $category->getProducts(
                    (int)Context::getContext()->language->id,
                    1,
                    (Configuration::get('HOME_FEATURED_NBR') ? (int)Configuration::get('HOME_FEATURED_NBR') : 8),
                    'position'
                ),
                array(),
                true
            );
            $hupi_scripts .= $this->addProductImpression($home_featured_products).$this->addProductClick($home_featured_products);
        }

        // New products
        if ($this->isModuleEnabled('ps_newproducts') && (Configuration::get('PS_NB_DAYS_NEW_PRODUCT')
                || Configuration::get('PS_BLOCK_NEWPRODUCTS_DISPLAY')))
        {
            $new_products = Product::getNewProducts((int)$this->context->language->id, 0, (int)Configuration::get('NEW_PRODUCTS_NBR'));
            $new_products_list = $this->wrapProducts($new_products, array(), true);
            $hupi_scripts .= $this->addProductImpression($new_products_list).$this->addProductClick($new_products_list);
        }

        // Best Sellers
        if ($this->isModuleEnabled('ps_bestsellers') && (!Configuration::get('PS_CATALOG_MODE')
                || Configuration::get('PS_BLOCK_BESTSELLERS_DISPLAY')))
        {
            $hupi_homebestsell_product_list = $this->wrapProducts(ProductSale::getBestSales((int)$this->context->language->id, 0, 8), array(), true);
            $hupi_scripts .= $this->addProductImpression($hupi_homebestsell_product_list).$this->addProductClick($hupi_homebestsell_product_list);
        }

        $this->js_state = 1;

        $this->_runJs($this->filter($hupi_scripts));

        if(Configuration::get('HUPIRECO_ACTIVE') != 1 || Configuration::get('HUPIRECO_HP_ACTIVE') != '1' || !Configuration::get('HUPIRECO_HP_ENDPOINT')) {
            return;
        }
        $nbProd = (int)Configuration::get('HUPIRECO_HP_NB');
        if($nbProd == 0) {
            $nbProd = null;
        }

        if($products = $this->getProducts(Configuration::get('HUPIRECO_HP_ENDPOINT'), $nbProd)) {
            $this->smarty->assign(array(
                'products' => $products,
                'endpoint' => Configuration::get('HUPIRECO_HP_ENDPOINT')
            ));

            foreach ($products as $product) {
                self::$recommendedProducts[] = $product['id_product'];
            }
            return $this->fetch('module:hupi/views/templates/hook/recommendations.tpl');
        }
    }

    public function hookdisplayHupiRecommendations($params)
    {
        if(Configuration::get('HUPIRECO_ACTIVE') != 1) {
            return;
        }

        if(isset($params['productId']) && $params['productId']) {
            $id_product = $params['productId'];

            if(isset($params['nbItems']) && $params['nbItems']) {
                $nbProd = (int)$params['nbItems'];
            } else {
                $nbProd = (int)Configuration::get('HUPIRECO_PROD_NB');
            }
            if($nbProd == 0) {
                $nbProd = null;
            }

            if($products = $this->getProducts(Configuration::get('HUPIRECO_PROD_ENDPOINT'), $nbProd, array('id_product' => $id_product))) {
                $this->smarty->assign(array(
                    'products' => $products,
                    'endpoint' => Configuration::get('HUPIRECO_PROD_ENDPOINT')
                ));

                foreach ($products as $product) {
                    self::$recommendedProducts[] = $product['id_product'];
                }
                return $this->fetch('module:hupi/views/templates/hook/recommendations.tpl');
            }
        } else {
            if(isset($params['nbItems']) && $params['nbItems']) {
                $nbProd = (int)$params['nbItems'];
            } else {
                $nbProd = (int)Configuration::get('HUPIRECO_HP_NB');
            }
            if($nbProd == 0) {
                $nbProd = null;
            }

            if($products = $this->getProducts(Configuration::get('HUPIRECO_HP_ENDPOINT'), $nbProd)) {
                $this->smarty->assign(array(
                    'products' => $products,
                    'endpoint' => Configuration::get('HUPIRECO_HP_ENDPOINT')
                ));

                foreach ($products as $product) {
                    self::$recommendedProducts[] = $product['id_product'];
                }
                return $this->fetch('module:hupi/views/templates/hook/recommendations.tpl');
            }


        }
        return ;
    }

    public function hookDisplayShoppingCartFooter($params)
    {
        if(Configuration::get('HUPIRECO_ACTIVE') != 1 || Configuration::get('HUPIRECO_CART_ACTIVE') != '1' || !Configuration::get('HUPIRECO_CART_ENDPOINT')) {
            return;
        }

        $nbProd = (int)Configuration::get('HUPIRECO_CART_NB');
        if($nbProd == 0) {
            $nbProd = null;
        }


        if($products = $this->getProducts(Configuration::get('HUPIRECO_CART_ENDPOINT'), $nbProd)) {
            $this->context->controller->addCss(_THEME_CSS_DIR_.'product_list.css', 'all');
            $this->smarty->assign(array(
                'products' => $products,
                'endpoint' => Configuration::get('HUPIRECO_CART_ENDPOINT')
            ));

            foreach ($products as $product) {
                self::$recommendedProducts[] = $product['id_product'];
            }
            return $this->fetch('module:hupi/views/templates/hook/shopping-cart.tpl');
        }

    }



    public function hookLeftColumn($params)
    {
        $controller = $this->context->controller->php_self;
        if(!$controller) {
            $controller = isset($this->context->controller->page_name) ? $this->context->controller->page_name : null;
        }

        if (Tools::getValue('id_category') && $controller == 'category') {
            $id_category = Tools::getValue('id_category');

            if(Configuration::get('HUPIRECO_ACTIVE') != 1 || Configuration::get('HUPIRECO_CATEGORY_ACTIVE') != '1' || !Configuration::get('HUPIRECO_CATEGORY_ENDPOINT')) {
                return;
            }

            $nbProd = (int)Configuration::get('HUPIRECO_CATEGORY_NB');
            if($nbProd == 0) {
                $nbProd = null;
            }

            if($products = $this->getProducts(Configuration::get('HUPIRECO_CATEGORY_ENDPOINT'), $nbProd, array('id_category' => $id_category))) {
                $this->context->controller->addCss(_THEME_CSS_DIR_.'product_list.css', 'all');
                $this->smarty->assign(array(
                    'products' => $products,
                    'endpoint' => Configuration::get('HUPIRECO_CATEGORY_ENDPOINT')
                ));

                foreach ($products as $product) {
                    self::$recommendedProducts[] = $product['id_product'];
                }
                return $this->fetch('module:hupi/views/templates/hook/category.tpl');
            }
        }
    }

    public function hookRightColumn($params) {
        return $this->hookLeftColumn($params);
    }
}
